/* =========================================================
   CARDÁPIO — ARQUIVO EDITÁVEL
   -----------------------------------------------------------
   Preencha aqui os itens reais do cardápio, com nomes,
   descrições e preços confirmados pelo cliente.
   Os valores abaixo são EXEMPLOS (placeholder) e devem
   ser substituídos antes da publicação final.

   Estrutura de cada item:
   {
     nome:  "Nome do item",
     desc:  "Descrição curta (opcional, pode deixar '')",
     preco: "R$ 0,00"   // texto livre, ex: "R$ 6,00" ou "A partir de R$ 6,00"
   }
========================================================= */

const CARDAPIO = {
  "Espetinhos": [
    { nome: "Espetinho de carne bovina", desc: "Exemplo — confirmar corte e preço", preco: "R$ --,--" },
    { nome: "Espetinho de frango",       desc: "Exemplo — confirmar tempero e preço", preco: "R$ --,--" },
    { nome: "Espetinho de linguiça",     desc: "Exemplo — confirmar preço", preco: "R$ --,--" },
    { nome: "Espetinho de coração",      desc: "Exemplo — confirmar preço", preco: "R$ --,--" }
  ],
  "Acompanhamentos": [
    { nome: "Farofa",         desc: "Exemplo — confirmar preço", preco: "R$ --,--" },
    { nome: "Vinagrete",      desc: "Exemplo — confirmar preço", preco: "R$ --,--" },
    { nome: "Pão de alho",    desc: "Exemplo — confirmar preço", preco: "R$ --,--" }
  ],
  "Bebidas": [
    { nome: "Refrigerante lata",  desc: "Exemplo — confirmar marca/preço", preco: "R$ --,--" },
    { nome: "Água mineral",       desc: "Exemplo — confirmar preço", preco: "R$ --,--" },
    { nome: "Cerveja long neck",  desc: "Exemplo — confirmar marca/preço", preco: "R$ --,--" }
  ]
};

/* =========================================================
   HORÁRIO DE FUNCIONAMENTO — ARQUIVO EDITÁVEL
   Preencha com o horário real confirmado pelo cliente.
========================================================= */
const HORARIOS = [
  { dia: "Segunda-feira", hora: "A confirmar" },
  { dia: "Terça-feira",   hora: "A confirmar" },
  { dia: "Quarta-feira",  hora: "A confirmar" },
  { dia: "Quinta-feira",  hora: "A confirmar" },
  { dia: "Sexta-feira",   hora: "A confirmar" },
  { dia: "Sábado",        hora: "A confirmar" },
  { dia: "Domingo",       hora: "A confirmar" }
];
