(function () {
  "use strict";

  var WHATS_NUMERO = "5594984099459";

  function linkPedido(nomeItem) {
    var msg = "Olá! Quero pedir: " + nomeItem;
    return "https://wa.me/" + WHATS_NUMERO + "?text=" + encodeURIComponent(msg);
  }

  /* ---------- Menu (cardápio) ---------- */
  function montarCardapio() {
    var tabsEl = document.getElementById("cardapioTabs");
    var listaEl = document.getElementById("cardapioLista");
    if (!tabsEl || !listaEl || typeof CARDAPIO === "undefined") return;

    var categorias = Object.keys(CARDAPIO);

    categorias.forEach(function (cat, i) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.textContent = cat;
      btn.setAttribute("role", "tab");
      btn.setAttribute("aria-selected", i === 0 ? "true" : "false");
      if (i === 0) btn.classList.add("active");
      btn.addEventListener("click", function () {
        tabsEl.querySelectorAll("button").forEach(function (b) {
          b.classList.remove("active");
          b.setAttribute("aria-selected", "false");
        });
        btn.classList.add("active");
        btn.setAttribute("aria-selected", "true");
        renderizarCategoria(cat);
      });
      tabsEl.appendChild(btn);
    });

    function renderizarCategoria(cat) {
      listaEl.innerHTML = "";
      (CARDAPIO[cat] || []).forEach(function (item) {
        var card = document.createElement("div");
        card.className = "item";
        card.innerHTML =
          '<div class="item-main">' +
            '<p class="item-nome">' + item.nome + "</p>" +
            (item.desc ? '<p class="item-desc">' + item.desc + "</p>" : "") +
          "</div>" +
          '<div class="item-side">' +
            '<span class="item-preco">' + item.preco + "</span>" +
            '<a class="item-pedir" target="_blank" rel="noopener" href="' + linkPedido(item.nome) + '">Pedir</a>' +
          "</div>";
        listaEl.appendChild(card);
      });
    }

    if (categorias.length) renderizarCategoria(categorias[0]);
  }

  /* ---------- Horário ---------- */
  function montarHorario() {
    var el = document.getElementById("horarioLista");
    if (!el || typeof HORARIOS === "undefined") return;
    HORARIOS.forEach(function (h) {
      var li = document.createElement("li");
      li.innerHTML = "<span>" + h.dia + "</span><span>" + h.hora + "</span>";
      el.appendChild(li);
    });
  }

  /* ---------- Menu mobile ---------- */
  function montarNavToggle() {
    var toggle = document.getElementById("navToggle");
    var nav = document.getElementById("mainNav");
    if (!toggle || !nav) return;
    toggle.addEventListener("click", function () {
      var aberto = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", aberto ? "true" : "false");
    });
    nav.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* ---------- Ano no rodapé ---------- */
  function montarAno() {
    var el = document.getElementById("ano");
    if (el) el.textContent = new Date().getFullYear();
  }

  document.addEventListener("DOMContentLoaded", function () {
    montarCardapio();
    montarHorario();
    montarNavToggle();
    montarAno();
  });
})();
